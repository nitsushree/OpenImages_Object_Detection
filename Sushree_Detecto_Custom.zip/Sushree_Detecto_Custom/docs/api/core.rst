.. _core:

detecto.core
============

.. automodule:: detecto.core
   :members:
   :special-members:

.. autoclass:: detecto.core.Model
   :members:
   :special-members: __init__