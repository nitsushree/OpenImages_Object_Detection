.. _utils:

detecto.utils
=============

.. automodule:: detecto.utils
   :members: