.. _visualize:

detecto.visualize
=================

.. automodule:: detecto.visualize
   :members:
